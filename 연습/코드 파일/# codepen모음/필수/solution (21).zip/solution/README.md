# Solution

A Pen created on CodePen.io. Original URL: [https://codepen.io/GreenSock/pen/qBwRgXZ](https://codepen.io/GreenSock/pen/qBwRgXZ).

